package servlet;

import dao.BookDAO;
import model.Book;

import javax.ejb.EJB;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/add")
public class AddBookServlet extends HttpServlet {
    @EJB
    BookDAO bookDAO;

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        Book book = new Book();
        book.setTitle(req.getParameter("title"));
        book.setAuthor(req.getParameter("author"));
        bookDAO.addBook(book);
        res.sendRedirect("view.jsp");
    }
}