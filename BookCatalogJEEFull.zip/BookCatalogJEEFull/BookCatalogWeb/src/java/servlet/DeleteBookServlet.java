package servlet;

import dao.BookDAO;

import javax.ejb.EJB;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/delete")
public class DeleteBookServlet extends HttpServlet {
    @EJB
    BookDAO bookDAO;

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        bookDAO.deleteBook(id);
        res.sendRedirect("view.jsp");
    }
}